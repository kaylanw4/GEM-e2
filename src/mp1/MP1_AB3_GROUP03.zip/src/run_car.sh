while true 
do
    python3 reset.py
    python3 main.py
done